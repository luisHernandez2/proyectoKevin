<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html lang="es" class="no-js"> <!--<![endif]-->
  <head>
      <title></title>
      <?php include('include/head.html'); ?>
      <?php include('include/meta-social.html'); ?>
  </head>
  <body>
  	<?php include('include/footer.html'); ?>
  	<?php include('include/js-general.html'); ?>    
    </body>
</html>